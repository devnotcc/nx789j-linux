/*
 * Copyright (C) 2021 Jolla Ltd.
 * Copyright (C) 2021 Slava Monich <slava.monich@jolla.com>
 *
 * You may use this file under the terms of BSD license as follows:
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *   3. Neither the names of the copyright holders nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef GBINDER_OBJECT_CONVERTER_H
#define GBINDER_OBJECT_CONVERTER_H

#include "gbinder_types_p.h"

typedef struct gbinder_object_converter_functions {
    GBinderLocalObject* (*handle_to_local)(GBinderObjectConverter*, guint32,
        const GBinderRpcProtocol*, const void*);
    GBinderRemoteObject* (*local_to_remote)(GBinderObjectConverter*, void*);
} GBinderObjectConverterFunctions;

struct gbinder_object_converter {
    const GBinderObjectConverterFunctions* f;
    const GBinderIo* io;
    const GBinderRpcProtocol* protocol;
};

/* Inline wrappers */

GBINDER_INLINE_FUNC
GBinderLocalObject*
gbinder_object_converter_handle_to_local(
    GBinderObjectConverter* convert,
    guint32 handle,
    const GBinderRpcProtocol* protocol,
    const void* extra)
{
    return convert ? convert->f->handle_to_local(convert, handle,
        protocol, extra) : NULL;
}

GBINDER_INLINE_FUNC
GBinderRemoteObject*
gbinder_object_converter_local_to_remote(
    GBinderObjectConverter* convert,
    void* pointer)
{
    return (convert && convert->f->local_to_remote) ?
        convert->f->local_to_remote(convert, pointer) : NULL;
}

#endif /* GBINDER_OBJECT_CONVERTER_H */

/*
 * Local Variables:
 * mode: C
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
