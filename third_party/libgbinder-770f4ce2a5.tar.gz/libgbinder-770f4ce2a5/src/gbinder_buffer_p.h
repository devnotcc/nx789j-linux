/*
 * Copyright (C) 2018-2022 Jolla Ltd.
 * Copyright (C) 2018-2022 Slava Monich <slava.monich@jolla.com>
 *
 * You may use this file under the terms of BSD license as follows:
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *   3. Neither the names of the copyright holders nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef GBINDER_BUFFER_PRIVATE_H
#define GBINDER_BUFFER_PRIVATE_H

#include <gbinder_buffer.h>

#include "gbinder_types_p.h"

GBinderBuffer*
gbinder_buffer_new(
    GBinderDriver* driver,
    void* data,
    gsize size,
    void** objects)
    GBINDER_INTERNAL;

GBinderBuffer*
gbinder_buffer_new_with_parent(
    GBinderBuffer* parent,
    void* data,
    gsize size)
    GBINDER_INTERNAL;

GBinderDriver*
gbinder_buffer_driver(
    GBinderBuffer* buf)
    GBINDER_INTERNAL;

GBinderBufferContents*
gbinder_buffer_contents(
    GBinderBuffer* buf)
    GBINDER_INTERNAL;

gconstpointer
gbinder_buffer_data(
    GBinderBuffer* buf,
    gsize* size)
    GBINDER_INTERNAL;

const GBinderIo*
gbinder_buffer_io(
    GBinderBuffer* buf)
    GBINDER_INTERNAL;

const GBinderRpcProtocol*
gbinder_buffer_protocol(
    GBinderBuffer* buf)
    GBINDER_INTERNAL;

void**
gbinder_buffer_objects(
    GBinderBuffer* buffer)
    GBINDER_INTERNAL;

GBinderBufferContents*
gbinder_buffer_contents_ref(
    GBinderBufferContents* contents)
    GBINDER_INTERNAL;

void
gbinder_buffer_contents_unref(
    GBinderBufferContents* contents)
    GBINDER_INTERNAL;

GBinderBufferContentsList*
gbinder_buffer_contents_list_add(
    GBinderBufferContentsList* list,
    GBinderBufferContents* contents)
    GBINDER_INTERNAL;

GBinderBufferContentsList*
gbinder_buffer_contents_list_dup(
    GBinderBufferContentsList* list)
    GBINDER_INTERNAL;

void
gbinder_buffer_contents_list_free(
    GBinderBufferContentsList* list)
    GBINDER_INTERNAL;

#endif /* GBINDER_BUFFER_PRIVATE_H */

/*
 * Local Variables:
 * mode: C
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
